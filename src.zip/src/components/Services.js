import { useNavigate } from "react-router-dom";


export const Services=()=>{
   
    const navigate=useNavigate();
    return(
        <div>
        <button type="button" className="btn btn-primary" onClick={(e)=>{
            e.preventDefault();
            navigate("/ServiceAdd")
        }} >
            Add
        </button>
        <input 
          type = "text"
          className = "service_id"
          placeholder = " Search by Id"
        />
        <input 
          type = "text"
          className = "service_name"
          placeholder = " Search by Name"
        />
    
    
    </div>
    );
   
}