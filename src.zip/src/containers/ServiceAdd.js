import React from "react";
import { useNavigate } from "react-router-dom";
export const ServiceAdd = () => {
    const navigate=useNavigate();
    return (
        <div>
            <form onSubmit={(e)=>{
                e.preventDefault();
                navigate("/Services")
            }}>
                <label>Add a Service:</label>
                <input
                    type="text"
                    className="service_name"
                    placeholder="Name Of The Service to be added"
                />
                <input
                    type="text"
                    className="service_cost"
                    placeholder="Cost Of The Service to be added"
                />
                <input
                    type="text"
                    className="service_category"
                    placeholder="Category Of The Service to be added"
                />
                <input type="submit" value="Submit" />
            </form>
        </div>
    );

}