export const ServiceDetails=()=>{
    return(
        <div>
            
        </div>
    );
}